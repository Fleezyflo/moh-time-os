PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS artifact_blobs (
  blob_id TEXT PRIMARY KEY,
  content_hash TEXT UNIQUE NOT NULL,
  payload BLOB NOT NULL,
  retention_class TEXT NOT NULL DEFAULT 'standard',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS artifacts (
  artifact_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  source_id TEXT NOT NULL,
  type TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  actor_person_id TEXT,
  payload_blob_id TEXT,
  content_hash TEXT NOT NULL,
  visibility_tags TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(source, source_id),
  FOREIGN KEY(payload_blob_id) REFERENCES artifact_blobs(blob_id)
);

CREATE TABLE IF NOT EXISTS artifact_excerpts (
  excerpt_id TEXT PRIMARY KEY,
  artifact_id TEXT NOT NULL,
  anchor_type TEXT NOT NULL,
  anchor_start INTEGER NOT NULL,
  anchor_end INTEGER NOT NULL,
  excerpt_text TEXT NOT NULL,
  redaction_status TEXT NOT NULL DEFAULT 'none',
  created_at TEXT NOT NULL,
  FOREIGN KEY(artifact_id) REFERENCES artifacts(artifact_id)
);

CREATE INDEX IF NOT EXISTS idx_artifacts_occurred_at ON artifacts(occurred_at);
CREATE INDEX IF NOT EXISTS idx_excerpts_artifact ON artifact_excerpts(artifact_id);
