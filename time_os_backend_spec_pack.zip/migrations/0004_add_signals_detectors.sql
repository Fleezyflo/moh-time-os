PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS signal_definitions (
  signal_type TEXT PRIMARY KEY,
  description TEXT NOT NULL,
  required_evidence_types TEXT,
  min_link_confidence REAL NOT NULL DEFAULT 0.6,
  min_interpretation_confidence REAL NOT NULL DEFAULT 0.6,
  formula_version TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS detector_versions (
  detector_id TEXT NOT NULL,
  version TEXT NOT NULL,
  parameters TEXT,
  released_at TEXT NOT NULL,
  PRIMARY KEY(detector_id, version)
);

CREATE TABLE IF NOT EXISTS detector_runs (
  run_id TEXT PRIMARY KEY,
  detector_id TEXT NOT NULL,
  version TEXT NOT NULL,
  scope_ref TEXT,
  inputs_hash TEXT NOT NULL,
  ran_at TEXT NOT NULL,
  output_counts TEXT,
  status TEXT NOT NULL,
  FOREIGN KEY(detector_id, version) REFERENCES detector_versions(detector_id, version)
);

CREATE TABLE IF NOT EXISTS signals (
  signal_id TEXT PRIMARY KEY,
  signal_type TEXT NOT NULL,
  entity_ref_type TEXT NOT NULL,
  entity_ref_id TEXT NOT NULL,
  value TEXT,
  detected_at TEXT NOT NULL,
  interpretation_confidence REAL NOT NULL,
  linkage_confidence_floor REAL NOT NULL,
  evidence_excerpt_ids TEXT NOT NULL,
  detector_id TEXT NOT NULL,
  detector_version TEXT NOT NULL,
  FOREIGN KEY(signal_type) REFERENCES signal_definitions(signal_type)
);

CREATE INDEX IF NOT EXISTS idx_signals_entity ON signals(entity_ref_type, entity_ref_id);
CREATE INDEX IF NOT EXISTS idx_signals_detected_at ON signals(detected_at);
