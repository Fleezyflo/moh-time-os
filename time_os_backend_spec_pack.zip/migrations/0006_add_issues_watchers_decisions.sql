PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS issues (
  issue_id TEXT PRIMARY KEY,
  source_proposal_id TEXT,
  issue_type TEXT NOT NULL,
  state TEXT NOT NULL,
  primary_ref_type TEXT NOT NULL,
  primary_ref_id TEXT NOT NULL,
  scope_refs TEXT NOT NULL,
  priority REAL NOT NULL,
  resolution_criteria TEXT NOT NULL,
  opened_at TEXT NOT NULL,
  last_activity_at TEXT NOT NULL,
  closed_at TEXT,
  created_by_tag INTEGER NOT NULL DEFAULT 1,
  visibility TEXT NOT NULL DEFAULT 'tagged_only'
);

CREATE TABLE IF NOT EXISTS issue_signals (
  issue_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  PRIMARY KEY(issue_id, signal_id),
  FOREIGN KEY(issue_id) REFERENCES issues(issue_id),
  FOREIGN KEY(signal_id) REFERENCES signals(signal_id)
);

CREATE TABLE IF NOT EXISTS issue_evidence (
  issue_id TEXT NOT NULL,
  excerpt_id TEXT NOT NULL,
  PRIMARY KEY(issue_id, excerpt_id),
  FOREIGN KEY(issue_id) REFERENCES issues(issue_id),
  FOREIGN KEY(excerpt_id) REFERENCES artifact_excerpts(excerpt_id)
);

CREATE TABLE IF NOT EXISTS decision_log (
  decision_id TEXT PRIMARY KEY,
  issue_id TEXT NOT NULL,
  actor TEXT NOT NULL,
  decision_type TEXT NOT NULL,
  note TEXT,
  evidence_excerpt_ids TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(issue_id) REFERENCES issues(issue_id)
);

CREATE TABLE IF NOT EXISTS watchers (
  watcher_id TEXT PRIMARY KEY,
  issue_id TEXT NOT NULL,
  watch_type TEXT NOT NULL,
  params TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  next_check_at TEXT NOT NULL,
  last_checked_at TEXT,
  triggered_at TEXT,
  trigger_count INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(issue_id) REFERENCES issues(issue_id)
);

CREATE INDEX IF NOT EXISTS idx_watchers_issue ON watchers(issue_id);
CREATE INDEX IF NOT EXISTS idx_issues_state ON issues(state);
