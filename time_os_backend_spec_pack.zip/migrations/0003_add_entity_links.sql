PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS entity_links (
  link_id TEXT PRIMARY KEY,
  from_artifact_id TEXT NOT NULL,
  to_entity_type TEXT NOT NULL,
  to_entity_id TEXT NOT NULL,
  method TEXT NOT NULL,
  confidence REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'proposed',
  confirmed_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(from_artifact_id) REFERENCES artifacts(artifact_id)
);

CREATE INDEX IF NOT EXISTS idx_links_from_artifact ON entity_links(from_artifact_id);
CREATE INDEX IF NOT EXISTS idx_links_to_entity ON entity_links(to_entity_type, to_entity_id);
