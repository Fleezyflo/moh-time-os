PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS proposals (
  proposal_id TEXT PRIMARY KEY,
  proposal_type TEXT NOT NULL,
  primary_ref_type TEXT NOT NULL,
  primary_ref_id TEXT NOT NULL,
  scope_refs TEXT NOT NULL,
  headline TEXT NOT NULL,
  impact TEXT,
  hypotheses TEXT,
  signal_ids TEXT NOT NULL,
  proof_excerpt_ids TEXT NOT NULL,
  missing_confirmations TEXT,
  score REAL NOT NULL,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,
  trend TEXT NOT NULL DEFAULT 'flat',
  supersedes_proposal_id TEXT,
  ui_exposure_level TEXT NOT NULL DEFAULT 'none',
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_proposals_primary ON proposals(primary_ref_type, primary_ref_id);
CREATE INDEX IF NOT EXISTS idx_proposals_status_score ON proposals(status, score);
