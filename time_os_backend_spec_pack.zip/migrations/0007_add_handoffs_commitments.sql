PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS handoffs (
  handoff_id TEXT PRIMARY KEY,
  issue_id TEXT NOT NULL,
  from_person_id TEXT,
  to_person_id TEXT NOT NULL,
  what_is_expected TEXT NOT NULL,
  due_at TEXT,
  done_definition TEXT,
  state TEXT NOT NULL DEFAULT 'proposed',
  created_at TEXT NOT NULL,
  FOREIGN KEY(issue_id) REFERENCES issues(issue_id)
);

CREATE TABLE IF NOT EXISTS commitments (
  commitment_id TEXT PRIMARY KEY,
  scope_ref TEXT NOT NULL,
  committed_by TEXT NOT NULL,
  commitment_text TEXT NOT NULL,
  due_at TEXT,
  confidence REAL NOT NULL,
  evidence_excerpt_ids TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL
);
