PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS couplings (
  coupling_id TEXT PRIMARY KEY,
  anchor_ref TEXT NOT NULL,
  entity_refs TEXT NOT NULL,
  strength REAL NOT NULL,
  why TEXT NOT NULL,
  investigation_path TEXT NOT NULL,
  confidence REAL NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS report_templates (
  template_id TEXT PRIMARY KEY,
  template_type TEXT NOT NULL,
  sections TEXT NOT NULL,
  default_scopes TEXT,
  version TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS report_snapshots (
  snapshot_id TEXT PRIMARY KEY,
  template_id TEXT NOT NULL,
  scope_ref TEXT NOT NULL,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  generated_at TEXT NOT NULL,
  content TEXT NOT NULL,
  evidence_excerpt_ids TEXT NOT NULL,
  immutable_hash TEXT NOT NULL,
  version TEXT NOT NULL,
  FOREIGN KEY(template_id) REFERENCES report_templates(template_id)
);

CREATE TABLE IF NOT EXISTS protocol_violations (
  violation_id TEXT PRIMARY KEY,
  violation_type TEXT NOT NULL,
  scope_refs TEXT NOT NULL,
  severity TEXT NOT NULL,
  evidence_excerpt_ids TEXT NOT NULL,
  detected_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS access_roles (
  role_id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  PRIMARY KEY(user_id, role_id),
  FOREIGN KEY(role_id) REFERENCES access_roles(role_id)
);

CREATE TABLE IF NOT EXISTS entity_acl (
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  can_read INTEGER NOT NULL DEFAULT 1,
  can_write INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(entity_type, entity_id, role_id),
  FOREIGN KEY(role_id) REFERENCES access_roles(role_id)
);

CREATE TABLE IF NOT EXISTS retention_rules (
  rule_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  artifact_type TEXT NOT NULL,
  retention_class TEXT NOT NULL,
  duration_days INTEGER NOT NULL,
  legal_hold_supported INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS redaction_markers (
  excerpt_id TEXT PRIMARY KEY,
  redaction_status TEXT NOT NULL,
  reason TEXT,
  actor TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(excerpt_id) REFERENCES artifact_excerpts(excerpt_id)
);
