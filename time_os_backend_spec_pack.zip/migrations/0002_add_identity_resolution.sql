PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS identity_profiles (
  profile_id TEXT PRIMARY KEY,
  profile_type TEXT NOT NULL,
  canonical_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS identity_claims (
  claim_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  claim_type TEXT NOT NULL,
  claim_value TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(claim_type, claim_value),
  FOREIGN KEY(profile_id) REFERENCES identity_profiles(profile_id)
);

CREATE TABLE IF NOT EXISTS identity_operations (
  op_id TEXT PRIMARY KEY,
  op_type TEXT NOT NULL,
  from_profile_ids TEXT NOT NULL,
  to_profile_ids TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_claims_profile ON identity_claims(profile_id);
