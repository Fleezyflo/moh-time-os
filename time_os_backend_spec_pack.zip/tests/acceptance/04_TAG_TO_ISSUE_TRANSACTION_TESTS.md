# Tag→Issue Transaction Tests

- T1: Atomicity (failure leaves no partial issue).
- T2: Attachments (issue_signals + issue_evidence).
- T3: Watcher creation by issue_type.
- T4: decision_log created with evidence ids.
