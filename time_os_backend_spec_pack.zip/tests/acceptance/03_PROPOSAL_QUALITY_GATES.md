# Proposal Quality Gates

- P1: No surfaced proposal without >=3 proof excerpts.
- P2: Hypotheses must reference signals; top hypothesis references >=2 signals.
- P3: Two confidences enforced (linkage vs interpretation).
- P4: Dedupe lineage updates occurrence_count and supersedes_proposal_id.
