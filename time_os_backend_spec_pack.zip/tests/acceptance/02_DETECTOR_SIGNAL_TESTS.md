# Detector/Signal Acceptance Tests

For each detector:
- run logged with detector_id/version
- signals emitted with anchored excerpts
- linkage and interpretation confidences provided

Include tests for:
- unanswered_client_thread
- meeting_action_missing_task
- blocker_age_exceeds
- calendar_collision_on_critical_owner
- invoice_overdue_coupled_with_delivery_block
