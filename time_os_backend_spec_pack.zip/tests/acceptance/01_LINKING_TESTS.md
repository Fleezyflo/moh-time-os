# Linking Acceptance Tests

- L1: client comms artifacts link to Client (confirmed) with confidence >= threshold.
- L2: ambiguous engagement linkage creates Fix Data item.
- L3: user confirmation makes link sticky (status=confirmed, method=user_confirmed).
- L4: coverage targets across golden dataset:
  - >=90% confirmed Client linkage for client comms
  - >=75% confirmed Engagement linkage for critical artifacts
