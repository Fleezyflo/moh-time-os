# Couplings, Reports, Policy Tests

- C1: Couplings include why(signal_ids/link_ids) and investigation_path.
- R1: Report snapshot immutability (hash stable; deltas separate).
- A1: ACL enforced on evidence queries.
- Retention: retention rules applied with legal hold support.
