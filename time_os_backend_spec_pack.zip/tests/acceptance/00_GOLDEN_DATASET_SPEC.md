# Golden Dataset Spec

Define ~30 real scenarios with ground truth links, expected signals, expected proposal bundles, and expected tag→issue outcomes.

Each scenario must specify:
- expected entity_links (confirmed/proposed)
- expected signals (types + evidence excerpt anchors)
- expected proposal headline + hypotheses
- whether proposal should surface (gates)
- tag→issue: watchers + resolution criteria + decision log
