# Proposals (Executive Briefings)

## Principle
Proposal is the unit of executive attention: hypotheses + signals + proof.

## proposals table (fields)
- proposal_id
- proposal_type
- primary_ref_type/id
- scope_refs (JSON)
- headline
- impact (JSON)
- hypotheses (JSON, each references signal_ids)
- signal_ids (JSON)
- proof_excerpt_ids (JSON)
- missing_confirmations (JSON)
- score
- first_seen_at, last_seen_at
- occurrence_count
- trend
- supersedes_proposal_id
- ui_exposure_level
- status (open|snoozed|dismissed|accepted)

## Surfacing gates (hard)
A proposal can surface only if:
- ≥3 proof excerpts AND
- linkage coverage meets threshold AND
- either:
  - top hypothesis references ≥2 signals, OR
  - proposal is routed to Fix Data as “insufficient evidence”.
