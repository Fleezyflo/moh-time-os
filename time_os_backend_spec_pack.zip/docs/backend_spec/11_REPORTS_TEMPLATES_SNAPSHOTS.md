# Reports: Templates and Snapshots

Goal: stable, board-ready but drillable reporting by Client/Brand/Engagement.

- report_templates define sections and versions.
- report_snapshots are immutable (hash) and evidence-linked.
- UI shows snapshot by default; live deltas appear separately.
