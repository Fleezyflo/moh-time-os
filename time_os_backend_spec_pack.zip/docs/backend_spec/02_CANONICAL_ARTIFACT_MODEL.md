# Canonical Artifact and Evidence Model

## Purpose
Normalize everything (email/chat/calendar/tasks/meetings/docs/invoices) into an auditable stream.

## Tables
### artifacts
- artifact_id (pk)
- source (gmail, gchat, calendar, asana, drive, minutes_gemini, billing, etc.)
- source_id (stable upstream id)
- type (message, thread, calendar_event, meeting, minutes, task_update, doc_update, invoice_update, etc.)
- occurred_at
- actor_person_id (nullable)
- payload_blob_id (nullable)
- content_hash (dedupe/integrity)
- visibility_tags (JSON)
- created_at

### artifact_blobs (immutable)
- blob_id (pk)
- content_hash (unique)
- payload (BLOB)
- retention_class
- created_at

### artifact_excerpts (proof anchors)
- excerpt_id (pk)
- artifact_id (fk)
- anchor_type (byte_span|timecode_span|quote_window)
- anchor_start, anchor_end
- excerpt_text (cached)
- redaction_status

## Proof contract
Every surfaced “proof bullet” MUST reference an excerpt_id.

## Immutability
Raw blobs are append-only; updates create new blobs + new artifacts.
