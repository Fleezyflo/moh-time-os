# Issues, Handoffs, Commitments

## Issues
Monitored loops created only by Tag.
States: open|monitoring|awaiting|blocked|mitigated|resolved|handed_over

## Handoffs
Track ownership transfer with explicit expectations and done-definition.

## Commitments
Extracted promises/SLAs from comms/meetings. Drive urgency + watcher creation.

## Resolution criteria
Issues resolve only when resolution_criteria evaluates true (reply received, blocker cleared, decision recorded, etc.).
