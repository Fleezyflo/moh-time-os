# Identity Resolution

## Goal
Canonical identities across sources:
- Person across Gmail/Chat/Calendar/Asana
- Org across client/brand naming variants
- Engagement aliasing

## Tables
- identity_profiles(profile_id, profile_type=person|org, canonical_name, status)
- identity_claims(profile_id, claim_type, claim_value, source, confidence)
- identity_operations(op_type=merge|split, from_profile_ids, to_profile_ids, actor, reason)

## Workflow
1) Ingest claims from connectors.
2) Resolve to profiles when confidence ≥ threshold.
3) Ambiguity creates Fix Data items.
4) User merge/split is recorded and becomes durable truth.

## Rule
All linkers/detectors should reference identity_profiles, not raw emails/handles.
