# Domain Spine and Invariants

## Canonical spine
Client → Brand → Engagement → Deliverable → Task

- Brand may be equivalent to Client (“client-as-brand”).
- Engagement unifies Project and Retainer (`engagement_type`).

## Hard invariants
1. Every Task belongs to exactly one Engagement OR is explicitly `untriaged=true`.
2. Every Engagement belongs to exactly one Brand OR is explicitly `untriaged=true`.
3. Every Brand belongs to exactly one Client OR is marked `is_client_as_brand=true`.

Violations must be detectable and actionable (see Protocol Violations).

## Protocol checkpoints (compliance)
- Request captured → Task created
- Task completed → Deliverable delivered (or explicitly waived)
- Meeting decision/action → Task/Issue created (or explicitly dismissed)
- Invoice sent → Acknowledged/paid or actively monitored
