# Tag → Issue Transaction (Atomic)

## Goal
Tagging a Proposal/Artifact creates a monitored Issue loop with audit and watchers.

## Steps (atomic)
1) create Issue (state=open, created_by_tag=true, visibility=tagged_only)
2) attach top signals + proof excerpts + hypotheses snapshot
3) create watchers (per issue_type + commitments)
4) mark proposal accepted (if proposal-driven)
5) write decision_log(tagged)

## Failure rule
Any failure rolls back; no partial issue.
