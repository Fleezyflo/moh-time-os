# Policy: ACL, Retention, Redaction

- Role-based access + entity-level ACL
- Retention rules by source/type with legal hold support
- Redaction markers for transcript excerpts

All evidence queries must enforce ACL; redacted excerpts must not leak original content.
