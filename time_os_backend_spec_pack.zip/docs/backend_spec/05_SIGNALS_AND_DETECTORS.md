# Signals and Detectors

## Definitions
- Signal: atomic, provable fact with evidence excerpts.
- Detector: versioned process producing signals.

## Tables
signal_definitions(signal_type, description, required_evidence_types, min_link_confidence, min_interpretation_confidence, formula_version)
detector_versions(detector_id, version, parameters, released_at)
detector_runs(run_id, detector_id, version, scope_ref, inputs_hash, ran_at, output_counts, status)
signals(signal_id, signal_type, entity_ref_type/id, value, detected_at, interpretation_confidence, linkage_confidence_floor, evidence_excerpt_ids, detector_id/version)

## Governance
- Version every detector.
- Log every run.
- UI must render both linkage confidence and interpretation confidence.

## Initial detector set (v1)
1) unanswered_client_thread
2) blocker_age_exceeds
3) owner_inactivity_vs_deadline
4) meeting_action_missing_task
5) calendar_collision_on_critical_owner
6) invoice_overdue_coupled_with_delivery_block
