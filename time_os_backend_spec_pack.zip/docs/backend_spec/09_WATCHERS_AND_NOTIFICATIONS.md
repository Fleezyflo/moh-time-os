# Watchers and Notifications

Watchers are triggers attached to Issues:
- no_reply_by
- no_status_change_by
- blocker_age_exceeds
- deadline_approach
- meeting_imminent
- invoice_overdue_change

Evaluation: event-driven + periodic sweep. Notifications are deduped derived events and must pass ACL checks.
