# Protocol Compliance and Violations

protocol_violations detect protocol breaks:
- request_no_task
- task_done_no_delivery
- meeting_decision_no_followup
- invoice_sent_no_ack

Violations emit signals and can generate proposals.
