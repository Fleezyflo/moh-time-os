# Time OS Backend Spec Change Pack (Index)

**Date:** 2026-02-05

**Objective:** Convert Time OS into a closed-loop executive operating system using:
Artifacts → Entity Links → Signals → Proposals → (Tag) → Issues → Watchers (+ Handoffs, Commitments, Couplings, Reports, Policy)

## How to read
1) 01 Domain spine + protocol
2) 02–04 Evidence + Identity + Linking graph
3) 05–07 Signals/Detectors, Proposals, Tag→Issue transaction
4) 08–13 Loop ops, Intersections, Reports, Compliance, Policy

## Non-goals
- No auto-sending communications (drafts are copy/paste only).
- No precise “hours worked” claims; only bands with coverage/confidence.

## Executive gating rule
Everything is ingested and tracked, but **only tagged items enter monitored loops** (Issues).
