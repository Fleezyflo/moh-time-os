# Entity Linking Graph

## Purpose
Attach artifacts to the spine and related entities via explicit edges with confidence.

## entity_links
- link_id
- from_artifact_id
- to_entity_type (client|brand|engagement|deliverable|task|person|invoice|thread|meeting)
- to_entity_id
- method (headers|participants|rule|similarity|user_confirmed)
- confidence (0..1)
- status (proposed|confirmed|rejected)
- confirmed_by (nullable)

## Fix Data generation
Create resolution items when:
- multiple candidates exist within small confidence delta
- confidence below minimum for critical artifact types (client comms, minutes, invoices)
- conflicting edges exist (e.g., thread linked to two engagements)

## Coverage metrics
- % artifacts with confirmed Client linkage
- % artifacts with confirmed Engagement linkage
