# Couplings / Intersections Engine

Couplings are computed objects that explain intersections with “why” and an investigation path.

couplings:
- anchor_ref (proposal/issue)
- entity_refs
- strength
- why (signal_ids + link_ids)
- investigation_path
- confidence
