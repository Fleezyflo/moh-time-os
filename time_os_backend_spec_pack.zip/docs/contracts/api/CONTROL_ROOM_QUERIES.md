# Control Room Query Contracts (UI ↔ Backend)

Snapshot:
- proposals: status=open, within horizon, passing surfacing gates
- issues: active (state != resolved/handed_over)
- watchers: due soon
- fix-data items: link/identity conflicts

Client scope:
- proposals scoped to client/brand/engagement
- issues scoped to same
- evidence timeline via artifacts + entity_links

Intersections:
- couplings for anchor proposal/issue + referenced excerpts
