# UI Contract: ProposalCard, IssueCard, RoomDrawer

ProposalCard must include:
- headline, impact, hypotheses, signals, proof excerpts, missing confirmations
- linkage_confidence + interpretation_confidence
Actions: Tag & Monitor, Snooze, Dismiss (+ optional Copy Draft)

IssueCard must include:
- state, priority, last_activity_at, next_trigger, resolution summary

RoomDrawer order:
1) Summary (what changed + why likely + proof)
2) Open Issues + Top Proposals
3) Evidence timeline
4) Actions (watchers, handoffs, drafts copy/paste)
